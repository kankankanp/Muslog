// Bridge: CloudFront origin-request -> API Gateway v2 event
// Also supports direct API Gateway v2 invocation (pass-through)
let cached;

function cfHeadersToSingleValue(headers) {
  const out = {};
  if (!headers) return out;
  for (const [k, arr] of Object.entries(headers)) {
    if (arr && arr.length) out[k.toLowerCase()] = arr[0].value;
  }
  return out;
}

function singleToCfHeaders(headers) {
  const out = {};
  for (const [k, v] of Object.entries(headers || {})) {
    if (v == null) continue;
    const key = k.toLowerCase();
    out[key] = Array.isArray(v)
      ? v.map((val) => ({ key: k, value: String(val) }))
      : [{ key: k, value: String(v) }];
  }
  return out;
}

exports.handler = async (event, context, callback) => {
  if (!cached) {
    const mod = await import('./index.mjs');
    cached = mod.handler || mod.default || mod;
    if (typeof cached !== 'function') {
      throw new Error('OpenNext server function export not found (handler/default).');
    }
  }

  // If already API Gateway v2 event, pass-through
  if (event && event.version === '2.0' && event.requestContext?.http) {
    try {
      const resp = await cached(event, context);
      // APIGW proxy integration expects the raw response
      return resp;
    } catch (e) {
      return { statusCode: 500, headers: { 'content-type': 'text/plain' }, body: 'SSR error' };
    }
  }

  // Otherwise, treat as CloudFront origin-request and convert
  const cf = event.Records?.[0]?.cf;
  if (!cf) return callback(null, { status: '500', body: 'Invalid event' });
  const req = cf.request;

  const headers = cfHeadersToSingleValue(req.headers);
  const rawQS = req.querystring || '';
  const body = req.body?.data ? (req.body.encoding === 'base64' ? req.body.data : Buffer.from(req.body.data, 'base64').toString('utf8')) : undefined;
  const isBase64Encoded = req.body?.encoding === 'base64';

  const apigwEvent = {
    version: '2.0',
    routeKey: '$default',
    rawPath: req.uri || '/',
    rawQueryString: rawQS,
    headers,
    requestContext: {
      http: {
        method: req.method || 'GET',
        path: req.uri || '/',
        protocol: headers['x-forwarded-proto'] ? `${headers['x-forwarded-proto'].toUpperCase()}` : 'HTTP/1.1',
        sourceIp: headers['x-forwarded-for'] || '',
        userAgent: headers['user-agent'] || '',
      },
      domainName: headers['host'] || '',
      timeEpoch: Date.now(),
    },
    isBase64Encoded,
    body,
  };

  try {
    const resp = await cached(apigwEvent, context);
    const cfResp = {
      status: String(resp.statusCode || 200),
      statusDescription: 'OK',
      headers: singleToCfHeaders(resp.headers || {}),
      body: resp.body || '',
    };
    if (resp.isBase64Encoded) {
      cfResp.bodyEncoding = 'base64';
    }
    return callback(null, cfResp);
  } catch (e) {
    return callback(null, {
      status: '500',
      statusDescription: 'Internal Server Error',
      headers: { 'content-type': [{ key: 'Content-Type', value: 'text/plain; charset=utf-8' }] },
      body: 'SSR bridge error',
    });
  }
};
